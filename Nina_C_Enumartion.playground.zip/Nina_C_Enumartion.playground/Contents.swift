import UIKit

enum Bread: CaseIterable {
    case wheat, white, sourdough
}
let number1 = Bread.allCases.count
print("There are -> \(number1) breads available")

enum Meat: CaseIterable {
    case ham, turkey, chicken
}
let number2 = Meat.allCases.count
print("There are -> \(number2) meats available")

enum Cheese: CaseIterable {
    case provolone, american, swiss, none
}
let number3 = Cheese.allCases.count
print("There are -> \(number3) cheese available")

enum Veggie: CaseIterable {
    case romainelettuce, pickle, tomato, none, all
}
let number4 = Veggie.allCases.count
print("There are -> \(number4) veggies available")

enum Condiment: CaseIterable {
    case mayo, ketchup, mustard, none, all
}
let number5 = Condiment.allCases.count
print("There are -> \(number4) condiments available")

enum Bread1 {
    case wheat
    case white
    case sourdough
}

var direction1 = Bread1.wheat

switch direction1 {
case.wheat:
    print("Place your wheat bread on a plate")
case.white:
    print("Place your white bread on a plate")
case.sourdough:
    print("Place your sourdough bread on a plate")
}

enum Meat1 {
    case ham
    case turkey
    case chicken
}

var direction2 = Meat1.ham

switch direction2 {
case.ham:
    print("Place your ham on top of your bread")
case.turkey:
    print("Place your turkey on top of your bread")
case.chicken:
    print("Place your chicken on top of your bread")
}

enum Cheese1 {
    case provolone
    case american
    case swiss
    case none
}

var direction3 = Cheese1.provolone

switch direction3 {
case.provolone:
    print("Place your provolone cheese on top of your meat")
case.american:
    print("Place your american cheese on top of your meat")
case.swiss:
    print("Place your swiss cheese on top of your meat")
case.none:
    print("Continue onto instruction 4")
}

enum Veggie1 {
    case romainelettuce
    case pickle
    case tomato
    case none
    case all
}

var direction4 = Veggie1.romainelettuce

switch direction4 {
case.romainelettuce:
    print("Place your romaine lettuce on top of your cheese")
case.pickle:
    print("Place your pickle on top of your cheese")
case.tomato:
    print("Place your tomato on top of your cheese")
case.none:
    print("Continue onto instruction 5")
case.all:
    print("Place all of the veggies on top of your cheese")
}

enum Condiments1 {
    case mayo
    case ketchup
    case mustard
    case none
    case all
}

var direction5 = Condiments1.mayo

switch direction5 {
case.mayo:
    print("Place your mayo on one side of your top bread slice and ENJOY!")
case.ketchup:
    print("Place your ketchup on top of your veggies and ENJOY!")
case.mustard:
    print("Place your mustard on top of your veggies and ENJOY!")
case.none:
    print("Place your bread together and ENJOY!")
case.all:
    print("Place all onto your sandwich and ENJOY!")
}
